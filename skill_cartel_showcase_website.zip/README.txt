SKILL CARTEL SHOWCASE WEBSITE

1. Keep your current working index.html unchanged.
2. Upload showcase.html to the root of your GitHub repository: panzymeal-art/Skill-Cartel.
3. Commit the upload.
4. Open https://panzymeal-art.github.io/Skill-Cartel/showcase.html

This lets you review the new public-facing website without replacing the existing AI app.
When ready, we can safely make this the homepage and move the AI app to its own page.

AI access is presented as consultation plus manual activation, not automatic payment processing.
The affiliate programme is marked as preparing, not open.
Social links are placeholders because the URLs have not been supplied.
The 40% partnership model is subject to a written contract.
